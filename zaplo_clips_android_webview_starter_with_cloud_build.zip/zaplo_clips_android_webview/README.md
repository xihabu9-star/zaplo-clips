# Zaplo Clips — Android WebView starter

This project wraps the Zaplo Clips mobile web UI in a basic Android app and includes a GitHub Actions workflow to build a test APK in the cloud.

## What works
- Opens the Zaplo Clips interface inside an Android app
- Lets the user choose a local video and preview it
- Lets the user choose aspect ratio, clip duration, caption style, and clip count
- Shows a status summary of the chosen settings
- GitHub Actions workflow builds a debug APK and uploads it as an artifact

## What does not work yet
- AI highlight detection
- Actual trimming/exporting of clips
- Speech recognition or auto captions
- Saving rendered output videos

Those need a real processing engine/backend. This starter does not claim to generate clips.

## Build APK using GitHub (phone-friendly path)
1. Extract this ZIP on your phone if possible, then upload the project files to a new GitHub repository. The `.github` folder must be included.
2. Open the repository's **Actions** tab.
3. Run **Build Zaplo Clips APK** (or push to the main/master branch).
4. When the workflow finishes, open the run and download the `zaplo-clips-debug-apk` artifact.
5. Extract the downloaded artifact ZIP; it contains the APK.

If uploading a whole folder from your phone is difficult, use GitHub's web interface or a trusted computer. A debug APK is for testing, not a Play Store release.

## Next development phase
Implement real media processing (for example, a bundled FFmpeg-based trimming pipeline) and speech-to-text/caption timing. This is not included in this starter yet.
